package bgu.spl.mics.application.passiveObjects;
import bgu.spl.mics.Event;
import bgu.spl.mics.Future;
import bgu.spl.mics.MessageBusImpl;
import bgu.spl.mics.application.messages.AttackEvent;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Passive object representing the resource manager.
 * <p>
 * This class must be implemented as a thread-safe singleton.
 * You must not alter any of the given public methods of this class.
 * <p>
 * You can add ONLY private methods and fields to this class.
 */
public class Ewoks {
    private static class EwoksHolder{
        private static Ewoks instance = new Ewoks();
    }

    private List<Ewok> ewokList;
    private List<Future<Boolean>> futureList;
    private int theOriginalTotalAttacks;

    private Ewoks(){
        ewokList = new LinkedList<>();
        futureList = new LinkedList<>();
        theOriginalTotalAttacks = 0;
    }

    public void setTheOriginalTotalAttacks(int num){
        this.theOriginalTotalAttacks = num;
    }
    public int getTheOriginalTotalAttacks(){
        return this.theOriginalTotalAttacks;
    }
    public void addNewFuture(Future<Boolean> future){
        this.futureList.add(future);
    }

    public List<Future<Boolean>> getFutureList(){
        return this.futureList;
    }

    public static Ewoks getInstance(){
        return EwoksHolder.instance;
    }

    public void addEwok(Ewok ewok){
        this.ewokList.add(ewok);
    }

    public Ewok getEwok(int serialNumber){
        Iterator<Ewok> iterator = this.ewokList.iterator();
        while (iterator.hasNext()){
            Ewok ewok = iterator.next();
            if(ewok.getSerialNumber() == serialNumber)
                return ewok;
        }
        return null;
    }

    public  boolean acquireNumberOfEwoks(List<Ewok> toAcquire,boolean x){
        boolean ans = true;
        if(!x) {
            for (Ewok ewok : toAcquire)
                if (ewok.tryAquire()) {
                    ewok.acquire();
                    ans = false;
                }
        }
        else if(x){
            for (Ewok ewok : toAcquire)
                if(ewok.tryAquire()) {
                    ewok.acquire();
                    ans = false;
                }
        }
        return ans;
    }


    public void releaseNumberOfEwoks(List<Ewok> toRelease){
        for(Ewok ewok: toRelease) {
            ewok.release();
        }
    }
}
