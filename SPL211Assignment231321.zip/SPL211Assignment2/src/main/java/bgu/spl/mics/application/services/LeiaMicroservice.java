package bgu.spl.mics.application.services;
import bgu.spl.mics.Future;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.messages.terminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Attack;
import bgu.spl.mics.application.passiveObjects.Ewoks;

/**
 * LeiaMicroservices Initialized with Attack objects, and sends them as  {@link AttackEvent}.
 * This class may not hold references for objects which it is not responsible for:
 * {@link AttackEvent}.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class LeiaMicroservice extends MicroService {
	private Attack[] attacks;

    public LeiaMicroservice(Attack[] attacks) {
        super("Leia");
		this.attacks = attacks;
    }

    @Override
    protected void initialize() {
        try{
            Thread.sleep(900);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.subscribeBroadcast(terminateBroadcast.class,(terminateBroadcast)->{
            this.terminate();
        });
    	for( int i = 0; i < attacks.length ; i = i + 1 ) {
    	    AttackEvent attackEvent = new AttackEvent(attacks[i]);
            Future<Boolean> future = this.sendEvent(attackEvent);
            Ewoks.getInstance().addNewFuture(future); //to help us make R2D2 wait for HANSOLO and C3PO to finish their run() in order for him to start its run().
        }
    }
}
