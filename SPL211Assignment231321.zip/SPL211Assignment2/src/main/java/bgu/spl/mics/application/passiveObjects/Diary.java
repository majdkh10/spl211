package bgu.spl.mics.application.passiveObjects;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Passive data-object representing a Diary - in which the flow of the battle is recorded.
 * We are going to compare your recordings with the expected recordings, and make sure that your output makes sense.
 * <p>
 * Do not add to this class nothing but a single constructor, getters and setters.
 */
public class Diary {

    private static class DiaryHolder{
        private static Diary instance = new Diary();
    }
    private transient AtomicInteger atomicIntegerAttacks;
    private int totalAttacks;
    private long HanSoloFinish;
    private long C3POFinish;
    private long R2D2Deactivate;
    private long LeiaTerminate;
    private long HanSoloTerminate;
    private long C3POTerminate;
    private long R2D2Terminate;
    private long LandoTerminate;

    public static Diary getInstance(){
        return DiaryHolder.instance;
    }
    public AtomicInteger getNumberOfAttacks(){
        return this.atomicIntegerAttacks;
    }

    public void resetNumberAttacks(){
        this.atomicIntegerAttacks = new AtomicInteger(0);
    }
    public int getAttacks(){
        return this.atomicIntegerAttacks.get();
    }



    public void addAttack() {
        int oldVal;
        int newVal;
        do {
            oldVal = getAttacks();
            newVal = oldVal + 1;
        }
        while (!atomicIntegerAttacks.compareAndSet(oldVal, newVal));
        setTotalAttacks( this.getAttacks());
    }
    private Diary(){
        this.atomicIntegerAttacks = new AtomicInteger(0);
        this.totalAttacks = 0;
        this.HanSoloFinish = 0;
        this.C3POFinish = 0;
        this.R2D2Deactivate = 0;
        this.LeiaTerminate = 0;
        this.HanSoloTerminate = 0;
        this.C3POTerminate = 0;
        this.R2D2Terminate = 0;
        this.LandoTerminate = 0;
    }

    public int getTotalAttacks(){
        return this.totalAttacks;
    }

    public long getHanSoloFinish(){
        return this.HanSoloFinish;
    }

    public long getC3POFinish(){
        return this.C3POFinish;
    }

    public long getR2D2Deactivate(){
        return this.R2D2Deactivate;
    }

    public long getLeiaTerminate(){
        return this.LeiaTerminate;
    }

    public long getHanSoloTerminate(){
        return this.HanSoloTerminate;
    }

    public long getC3POTerminate(){
        return this.C3POTerminate;
    }

    public long getR2D2Terminate(){
        return this.R2D2Terminate;
    }

    public long getLandoTerminate(){
        return this.LandoTerminate;
    }

    public void setTotalAttacks(int totalAttacks){
        this.totalAttacks = totalAttacks;
    }
    public void setHanSoloFinish(long timeToUpdate){
        this.HanSoloFinish = timeToUpdate;
    }

    public void setC3POFinish(long timeToUpdate){
        this.C3POFinish = timeToUpdate;
    }

    public void setR2D2Deactivate(long time){
        this.R2D2Deactivate = time;
    }

    public void setTerminate(long time){
        this.LandoTerminate = time;
        this.C3POTerminate = time;
        this.HanSoloTerminate = time;
        this.LeiaTerminate = time;
        this.R2D2Terminate = time;
    }

    public void getOutput(){
        System.out.print("totalAttacks:" + this.totalAttacks  + "\n" + "hansolofinish:" + this.HanSoloFinish +
                "\n" + "c3pofinish:" + this.C3POFinish + "\n" + "R2D2finish:" + this.R2D2Deactivate
                + "\n" + "R2D2Terminate : " +  this.R2D2Terminate + " \n"+ "leiaTerminate " + this.LeiaTerminate + "\n"
        + "hanTerminate "+this.HanSoloTerminate + "\n" + "landoTerminate " + this.LandoTerminate);
    }

}
