package bgu.spl.mics.application.services;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.Main;
import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.messages.DeactivationEvent;
import bgu.spl.mics.application.messages.terminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Diary;
import bgu.spl.mics.application.passiveObjects.Ewok;
import bgu.spl.mics.application.passiveObjects.Ewoks;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * C3POMicroservices is in charge of the handling {@link AttackEvent}.
 * This class may not hold references for objects which it is not responsible for:
 * {@link AttackEvent}.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class C3POMicroservice extends MicroService {

    public C3POMicroservice() {
        super("C3PO");
    }

    @Override
    protected void initialize() {
        this.subscribeBroadcast(terminateBroadcast.class,(terminateBroadcast)->{
            this.terminate();
        });
        this.subscribeEvent(AttackEvent.class,(obj)->{
            List<Integer> list = obj.getList();
            List<Ewok> ewokList = new LinkedList<>();
            Iterator<Integer> iterator = list.iterator();
            while(iterator.hasNext()){
                ewokList.add(Ewoks.getInstance().getEwok(iterator.next()));
            }
            boolean x=true;
            while(x) {
                Iterator<Ewok> ewokIterator = ewokList.iterator();
                while (ewokIterator.hasNext()) {
                    Ewok currEwok = ewokIterator.next();
                    if (!currEwok.getAvailable()) {
                        x=false;
                        currEwok.acquire();
                    }
                }
//            System.out.println("c3po " +obj.getList());
                x =Ewoks.getInstance().acquireNumberOfEwoks(ewokList,x);
            }
            try {
                Thread.sleep(obj.getDuration());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Ewoks.getInstance().releaseNumberOfEwoks(ewokList);
            this.complete(obj,true);
            Diary.getInstance().addAttack();
            int j = Diary.getInstance().getAttacks();
            if(j == Ewoks.getInstance().getTheOriginalTotalAttacks()){
                this.sendEvent(new DeactivationEvent());
            }
            Diary.getInstance().setC3POFinish(System.currentTimeMillis());
        });
    }
}