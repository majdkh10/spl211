package bgu.spl.mics;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {
	private static class MessageBusHolder {
		private static MessageBusImpl instance = new MessageBusImpl();
	}

	private ConcurrentHashMap<MicroService , BlockingQueue<Message>>  microserviceQueue;
	private	ConcurrentHashMap<Class<? extends Event> ,LinkedList<MicroService>> eventsMap;
	private ConcurrentHashMap<Class<? extends Broadcast>,LinkedList<MicroService>> broadcastMap;
	private ConcurrentHashMap<Event,Future> eventFutureConcurrentHashMap;

	private MessageBusImpl(){
		microserviceQueue = new ConcurrentHashMap<>();
		eventsMap = new ConcurrentHashMap<>();
		broadcastMap = new ConcurrentHashMap<>();
		eventFutureConcurrentHashMap = new ConcurrentHashMap<>();
	}

	public static MessageBusImpl getInstance(){
		return MessageBusHolder.instance;
	}

	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		synchronized (eventsMap) {
			if (eventsMap.get(type) == null) { //check if the type is not in the eventsMap
				LinkedList<MicroService> list = new LinkedList<>();
				list.add(m);
				eventsMap.put(type, list);
			} else {
				eventsMap.get(type).add(m);
			}
		}
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		synchronized (broadcastMap) {
			if (broadcastMap.get(type) == null) {
				LinkedList<MicroService> list = new LinkedList<>();
				list.add(m);
				broadcastMap.put(type, list);
			} else broadcastMap.get(type).add(m);

		}
	}

	@Override @SuppressWarnings("unchecked")
	public  <T> void complete(Event<T> e, T result) {
     	eventFutureConcurrentHashMap.get(e).resolve(result);
	}

	@Override
	public void sendBroadcast(Broadcast b) {
		synchronized (this) {
			if (broadcastMap.get(b.getClass()) != null) {
				Iterator<MicroService> iterator = broadcastMap.get(b.getClass()).iterator();
				while (iterator.hasNext()) {
					MicroService microService = iterator.next();
					microserviceQueue.get(microService).add(b);
				}
			}
		}
	}

	@Override
	public  <T> Future<T> sendEvent(Event<T> e) {
		Future<T> future = new Future<>();
		synchronized (eventsMap){
			if(!eventsMap.containsKey(e.getClass()) || eventsMap.get(e.getClass()).isEmpty())
				return null;
			MicroService microService = eventsMap.get(e.getClass()).remove();
			if(microserviceQueue.get(microService) == null)
				return null;
			eventFutureConcurrentHashMap.put(e,future);
			microserviceQueue.get(microService).add(e);
			eventsMap.get(e.getClass()).add(microService);
		}
		return future;
	}

	@Override
	public  void register(MicroService m) {
		if(microserviceQueue.get(m) == null)
			microserviceQueue.put(m, new LinkedBlockingQueue<>());
	}

	@Override
	public synchronized void unregister(MicroService m) {
		for(Class<? extends Event> key : eventsMap.keySet())
			eventsMap.get(key).remove(m);
		for(Class<? extends Broadcast> key : broadcastMap.keySet())
			broadcastMap.get(key).remove(m);
		microserviceQueue.remove(m);
	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		return this.microserviceQueue.get(m).take();
	}
}