package bgu.spl.mics;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.concurrent.TimeUnit;
import static org.junit.jupiter.api.Assertions.*;


public class FutureTest {

    private Future<String> future ;

    @BeforeEach
    public void setUp(){
       future = new Future<>();
    }

    @Test
    public void testResolve(){
        String str = "someResult";
        future.resolve(str);
        assertTrue(future.isDone());
        assertTrue(str.equals(future.get()));
    }

    @Test
    public void get() {
        assertFalse(future.isDone());
        String str = "str";
        future.resolve(str);
        assertTrue(future.get().equals(str));
        assertTrue(future.isDone());
    }

    @Test
    public void isDone(){
        assertFalse(future.isDone());
        String str = "randomResult";
        future.resolve(str);
        assertTrue(future.isDone());
    }

    @Test
    public void getTimeOut(){
        assertFalse(future.isDone());
        future.get(1000,TimeUnit.MILLISECONDS);
        assertFalse(future.isDone());
        String str = "randomResult";
        future.resolve(str);
        future.get(1000,TimeUnit.MILLISECONDS);
        assertEquals(str, future.get(1000, TimeUnit.MILLISECONDS));
        assertTrue(future.isDone());
    }
}
