package bgu.spl.mics;

import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.services.C3POMicroservice;
import bgu.spl.mics.application.services.HanSoloMicroservice;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageBusImplTest {

   private MessageBusImpl messageBus;

    @BeforeEach
    public void setUp() {
//        messageBus = new MessageBusImpl();
    }

    @Test
    public void complete() {
        HanSoloMicroservice hanSolo = new HanSoloMicroservice();
        messageBus.register(hanSolo);
        hanSolo.subscribeEvent(AttackEvent.class,(c)->{});
//        AttackEvent attackEvent = new AttackEvent();
//        Future future = hanSolo.sendEvent(attackEvent);
        boolean result = true;
//        future.resolve(result);
//        hanSolo.complete(attackEvent,result);
//        assertNotNull(future);
//        assertEquals(result, future.get());

    }

    //the "sendBroadcast()" test is the same as "subscribeBroadcast()"
    //so we are only going to test "sendBroadcast()"
    @Test
    public void sendBroadcast() {
        C3POMicroservice c3po = new C3POMicroservice();
        HanSoloMicroservice hanSolo = new HanSoloMicroservice();
        messageBus.register(hanSolo);
        messageBus.register(c3po);
//        Broadcast broadcast = new BroadcastImpl();
//        hanSolo.subscribeBroadcast(Broadcast.class, (c)->{});
//        c3po.subscribeBroadcast(Broadcast.class,(c)->{});
//        messageBus.sendBroadcast(broadcast);
//        Message a = null;
//        Message b = null;
//        try {
//             a = messageBus.awaitMessage(hanSolo);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        try{
//             b = messageBus.awaitMessage(hanSolo);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        assertTrue(a.equals(b));
    }

    //the test for the function "subscribeEvent()" ans "register()" is the same test of the function "sendEvent()"
    // so we only chose to test "sendEvent()" only

    @Test
    public void sendEvent() {
        HanSoloMicroservice hanSolo = new HanSoloMicroservice();
        messageBus.register(hanSolo);
        hanSolo.subscribeEvent(AttackEvent.class,(c)->{});
//        AttackEvent attackEvent1 = new AttackEvent();
//        messageBus.sendEvent(attackEvent1);
//        Message message = null;
//        try {
//            message = messageBus.awaitMessage(hanSolo);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        assertEquals(message, attackEvent1);
    }

    @Test
    public void awaitMessage() {
        HanSoloMicroservice hanSolo = new HanSoloMicroservice();
        messageBus.register(hanSolo);
//        AttackEvent attackEvent = new AttackEvent();
//        hanSolo.subscribeEvent(AttackEvent.class, (c)->{});
//        messageBus.sendEvent(attackEvent);
//        Message message = null;
//        try{
//            message = messageBus.awaitMessage(hanSolo);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        assertEquals(message,attackEvent);
    }
}