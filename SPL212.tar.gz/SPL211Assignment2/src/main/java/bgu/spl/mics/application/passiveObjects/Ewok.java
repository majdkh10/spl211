package bgu.spl.mics.application.passiveObjects;

/**
 * Passive data-object representing a forest creature summoned when HanSolo and C3PO receive AttackEvents.
 * You must not alter any of the given public methods of this class.
 * <p>
 * You may add fields and methods to this class as you see fit (including public methods).
 */
public class Ewok {

	private int serialNumber;
	private boolean available;
    protected int free; //numbers of the threads that have the current ewok
    protected int holdByOneThreadOnly;//

    public Ewok(int serialNumber){
        this.serialNumber = serialNumber;
        this.available = true;          //true means the current Ewok is free
        this.free = 1;
        this.holdByOneThreadOnly = 1;
    }

    public synchronized boolean tryAquire(){
    if(free == 1)
        return true;
    else return false;
    }

    /**
     * Acquires an Ewok
     */
    public synchronized void acquire() {
        while(free <= 0) {
            //if free == 0 then all threads are working on the current ewok,thus the new acquring thread will wait untill the current ewok is released
            try {
                this.wait();
                System.out.println("--------waiting" + serialNumber);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if(available == true){
            available = false;
            free=free-1; //minus one because a new thread is going to work now on the current ewok
            System.out.println("--------acquired" +serialNumber);
        }
    }

    /**
     * release an Ewok
     */
    public synchronized void release() {
        if(free < holdByOneThreadOnly && available == false) {
            free = 1;
            available = true;
            System.out.println("--------released " + serialNumber);
            this.notifyAll();
        }
    }

    public int getSerialNumber(){
        return this.serialNumber;
    }

    public boolean getAvailable(){
        return this.available;
    }
}