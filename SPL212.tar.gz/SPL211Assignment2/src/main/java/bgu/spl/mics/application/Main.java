package bgu.spl.mics.application;
import bgu.spl.mics.Input;
import bgu.spl.mics.InputReaderJson;
import bgu.spl.mics.application.passiveObjects.Diary;
import bgu.spl.mics.application.passiveObjects.Ewok;
import bgu.spl.mics.application.passiveObjects.Ewoks;
import bgu.spl.mics.application.services.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileWriter;
import java.io.IOException;

/** This is the Main class of the application. You should parse the input file,
 * create the different components of the application, and run the system.
 * In the end, you should output a JSON.
 */

public class Main {

	public static int getTotalNumbreOfAttacks(){
		int numberOfAttacks = 0;
		try {
			numberOfAttacks = InputReaderJson.getInputFromJson("/home/spl211/Desktop/SPL211Assignment2/src/main/java/bgu/spl/mics/Tests.json").getAttacks().length;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return numberOfAttacks;
	}

	public static void main(String[] args) {
		Diary diary = Diary.getInstance();
			try{
				Ewoks ewoks = Ewoks.getInstance();
				Input Json = InputReaderJson.getInputFromJson("/home/spl211/Desktop/SPL211Assignment2/input.json");
				for(int i = 1 ; i <= Json.getEwoks() ; i=i+1){
					ewoks.addEwok(new Ewok((i)));
				}
				LeiaMicroservice leiaMicroservice = new LeiaMicroservice(Json.getAttacks());
				HanSoloMicroservice hanSoloMicroservice = new HanSoloMicroservice();
				C3POMicroservice c3POMicroservice = new C3POMicroservice();
				R2D2Microservice r2D2Microservice = new R2D2Microservice(Json.getR2D2());
				LandoMicroservice landoMicroservice = new LandoMicroservice(Json.getLando());
				Thread LEIAThread = new Thread(leiaMicroservice);
				Thread HANSOLOThread = new Thread(hanSoloMicroservice);
				Thread C3POThread = new Thread(c3POMicroservice);
				Thread R2D2Thread = new Thread(r2D2Microservice);
				Thread LANDOThread = new Thread(landoMicroservice);
				LEIAThread.start();
				HANSOLOThread.start();
				C3POThread.start();
				R2D2Thread.start();
				LANDOThread.start();
				try {
					LEIAThread.join();
					HANSOLOThread.join();
					C3POThread.join();
					R2D2Thread.join();
					LANDOThread.join();
				} catch (InterruptedException e) {

				}
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter outputFileWriter = new FileWriter(args[1]);
					gson.toJson(Diary.getInstance(),outputFileWriter);
					outputFileWriter.flush();
					outputFileWriter.close();

				} catch (IOException e) {
				}
			} catch (IOException e) {
				e.printStackTrace();
			}


	}

}
