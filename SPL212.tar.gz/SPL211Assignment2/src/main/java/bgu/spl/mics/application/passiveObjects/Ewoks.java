package bgu.spl.mics.application.passiveObjects;
import bgu.spl.mics.Event;
import bgu.spl.mics.Future;
import bgu.spl.mics.MessageBusImpl;
import bgu.spl.mics.application.messages.AttackEvent;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Passive object representing the resource manager.
 * <p>
 * This class must be implemented as a thread-safe singleton.
 * You must not alter any of the given public methods of this class.
 * <p>
 * You can add ONLY private methods and fields to this class.
 */
public class Ewoks<list> {
    private static class EwoksHolder{
        private static Ewoks instance = new Ewoks();
    }

    private ConcurrentHashMap<AttackEvent , Future<Boolean>> attackEventFutureConcurrentHashMap;
    private List<AttackEvent> Attacklist;
    private List<Ewok> ewokList;
//    private AtomicInteger atomicIntegerAttacks ;

    private Ewoks(){
        ewokList = new LinkedList<>();
        Attacklist = new LinkedList<>();
//        this.atomicIntegerAttacks=new AtomicInteger(0);
        this.attackEventFutureConcurrentHashMap = new ConcurrentHashMap<>();
    }


    public static Ewoks getInstance(){
        return EwoksHolder.instance;
    }

    public void addToEventFutureConcurrentHashMap(AttackEvent attackEvent , Future<Boolean> future){

        this.attackEventFutureConcurrentHashMap.put(attackEvent,future);
    }

    public void addAttackEvent(AttackEvent attackEvent){
        Attacklist.add(attackEvent);
    }

    public List<AttackEvent> getAttacklist(){
        return Attacklist;
    }

    public Future<Boolean> getattackEventFutureConcurrentHashMap(AttackEvent attackEvent){
        return attackEventFutureConcurrentHashMap.get(attackEvent);
    }

    public void addEwok(Ewok ewok){
        this.ewokList.add(ewok);
    }


    public Ewok getEwok(int serialNumber){
        Iterator<Ewok> iterator = this.ewokList.iterator();
        while (iterator.hasNext()){
            Ewok ewok = iterator.next();
            if(ewok.getSerialNumber() == serialNumber)
                return ewok;
        }
        return null;
    }


    public void acquireNumberOfEwoks(List<Ewok> toAcquire){
        for(Ewok ewok: toAcquire)
            if(ewok.tryAquire()) {
                ewok.acquire();
            }
    }

    public void releaseNumberOfEwoks(List<Ewok> toRelease){
        for(Ewok ewok: toRelease) {
            ewok.release();
        }
    }
}
