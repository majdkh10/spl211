package bgu.spl.mics;

import bgu.spl.mics.application.passiveObjects.Ewok;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EwokTest {
    private Ewok ewok;

    @BeforeEach
    public void setUp() {
        ewok = new Ewok(0);
    }
//
//    @Test
//    public void acquire() {
//        assertTrue(ewok.available);
//        ewok.acquire();
//        assertFalse(ewok.available);
//        ewok.acquire();
//        assertFalse(ewok.available);
//    }
//
//    @Test
//    public void release() {
//        assertTrue(ewok.available);
//        ewok.acquire();
//        ewok.release();
//        assertTrue(ewok.available);
//        ewok.release();
//        assertTrue(ewok.available);
//
//    }
}