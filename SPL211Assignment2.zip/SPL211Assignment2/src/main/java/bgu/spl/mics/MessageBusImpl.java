package bgu.spl.mics;
import javax.swing.plaf.metal.MetalIconFactory;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus interface.
 * Write your implementation here!
 * Only private fields and methods can be added to this class.
 */
public class MessageBusImpl implements MessageBus {
	private static class MessageBusHolder {
		private static MessageBusImpl instance = new MessageBusImpl();
	}

	private ConcurrentHashMap<MicroService , BlockingQueue<Message>>  microserviceQueue;
	private	ConcurrentHashMap<Class<? extends Event> ,LinkedList<MicroService>> eventsMap;
	private ConcurrentHashMap<Class<? extends Broadcast>,LinkedList<MicroService>> broadcastMap;
	private ConcurrentHashMap<Event,Future> eventFutureConcurrentHashMap;
	private Object lockEvent = new Object();
	private Object lockBroadcast = new Object();

	private MessageBusImpl(){
		microserviceQueue = new ConcurrentHashMap<>();
		eventsMap = new ConcurrentHashMap<>();
		broadcastMap = new ConcurrentHashMap<>();
		eventFutureConcurrentHashMap = new ConcurrentHashMap<>();
	}

	public static MessageBusImpl getInstance(){
		return MessageBusHolder.instance;
	}

	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		synchronized (eventsMap) {
//			System.out.println("SubEvent ");
			if (eventsMap.get(type) == null) {
				LinkedList<MicroService> list = new LinkedList();
				list.add(m);
				eventsMap.put(type, list);
			} else {

				eventsMap.get(type).add(m);

			}
		}
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		synchronized (broadcastMap) {
//			System.out.println("SubBroadcast");
			if (broadcastMap.get(type) == null) {
				LinkedList<MicroService> list = new LinkedList();
				list.add(m);
				broadcastMap.put(type, list);
			} else broadcastMap.get(type).add(m);

		}
	}

	@Override @SuppressWarnings("unchecked")
	public  <T> void complete(Event<T> e, T result) {
//		System.out.println("complete");
		//synchornized iff there is a chance that two or more threds get the same event because of the round robin manner
     	eventFutureConcurrentHashMap.get(e).resolve(result);
	}

	@Override
	public  void sendBroadcast(Broadcast b) {//to synchronize or not
		synchronized (broadcastMap) {
			if (broadcastMap.get(b.getClass()) != null) {
				Iterator<MicroService> iterator = broadcastMap.get(b.getClass()).iterator();
				while (iterator.hasNext()) {
					MicroService microService = iterator.next();
//					if(microserviceQueue.get(microService)!= null)
					microserviceQueue.get(microService).add(b);

				}
/*
Future<T> future = new Future<>();
		eventFutureConcurrentHashMap.put(e,future);
		synchronized (eventsMap){
			if(!eventsMap.containsKey(e.getClass()))
				return null;
			if(eventsMap.get(e.getClass()).isEmpty())
				return null;
			MicroService microService = eventsMap.get(e.getClass()).remove();
			if(microserviceQueue.get(microService) == null) return null;
			microserviceQueue.get(microService).add(e);
			eventsMap.get(e.getClass()).add(microService);
		}
		return future;
 */
				//			System.out.println("SendBroadcast");
//			LinkedList<MicroService> listOfMicroservices = new LinkedList<>();
//			if(broadcastMap.get(b.getClass()) != null)
//			listOfMicroservices = broadcastMap.get(b.getClass());
//			for (MicroService microService : listOfMicroservices) {
//				if (microserviceQueue.get(microService) != null) {
//					microserviceQueue.get(microService).add(b);
//				}
//			}

			}
		}
	}

	@Override
	public  <T> Future<T> sendEvent(Event<T> e) {
		Future<T> future = new Future<>();
		eventFutureConcurrentHashMap.put(e,future);
		synchronized (eventsMap){
			if(!eventsMap.containsKey(e.getClass()))
				return null;
			if(eventsMap.get(e.getClass()).isEmpty())
				return null;
			MicroService microService = eventsMap.get(e.getClass()).remove();
			if(microserviceQueue.get(microService) == null) return null;
			microserviceQueue.get(microService).add(e);
			eventsMap.get(e.getClass()).add(microService);
		}
		return future;
////			System.out.println("SendEvent " + e.getClass());
//			//to check when there is no subscribed microservice to this type of event
////		Future future = null;
//			if (eventsMap.containsKey(e.getClass())) {
//				LinkedList<MicroService> list = eventsMap.get(e.getClass());
//				if(list==null || list.size() == 0)
//					return null;
//				MicroService microService = list.remove();
////				System.out.println("sending microservicce 4444444444444 " + microService.getName());
////				if (microserviceQueue.get(microService) == null) {
////					return null;
//
////					System.out.println("size of = " + microserviceQueue.get(microService).size() + "=======================");
//					microserviceQueue.get(microService).add(e);
////					System.out.println("size of = " + microserviceQueue.get(microService).size() + "=======   " + microserviceQueue.get(microService).peek() + "the name = " + microService.getName());
//
//				Future<T> future = new Future<>();
//				eventFutureConcurrentHashMap.put(e, future);
//				list.add(microService);
////			eventsMap.put((Class<? extends Event<?>>) e.getClass(),list);
//				return future;
////			future = eventFutureConcurrentHashMap.get(e);
//			}
//			//return eventFutureConcurrentHashMap.get(
//			return null;
//		}
	}

	@Override
	public  void register(MicroService m) {
		//synchronized
		//if so, we need an if for if the queue is null
		if(microserviceQueue.get(m) == null)
			microserviceQueue.put(m, new LinkedBlockingQueue<>());
	}

	@Override
	public synchronized void unregister(MicroService m) {
//		BlockingQueue blockingQueue = microserviceQueue.get(m);
//		Iterator<Message> iterator = blockingQueue.iterator();
//		while(iterator.hasNext()){
//			Message message = iterator.next();
//			if(message.getClass().isInstance(Event.class)){
////				eventFutureConcurrentHashMap.remove(message);
//				LinkedList Eventlist = eventsMap.get(message);
//				for(Object micro : Eventlist){
//					if(micro.equals(m)){
//						Eventlist.remove(m);
//					}
//				}
//			}
//
//			if(message.getClass().isInstance(Broadcast.class)){
//				LinkedList list = broadcastMap.get(message);
//				for(Object micro : list){
//					if(micro.equals(m)){
//						list.remove(m);
//					}
//				}
//			}
		for(Class<? extends Event> key : eventsMap.keySet())
			eventsMap.get(key).remove(m);
		for(Class<? extends Broadcast> key : broadcastMap.keySet())
			broadcastMap.get(key).remove(m);
		microserviceQueue.remove(m);
		}


	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
//		System.out.println("messagefadffjasnfasj = " + microserviceQueue.get(m).size() + "======================="+ m.getName()+"   -----------");
		BlockingQueue<Message> queue = this.microserviceQueue.get(m);
//		System.out.println("current blockingQueue size = " + queue.size());
		Message message = queue.take();
//		System.out.println("message scsafsa of = " + microserviceQueue.get(m).size() + "=======================");
		return message;
	}

}