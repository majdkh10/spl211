package bgu.spl.mics.application.services;
import java.util.*;
import bgu.spl.mics.Future;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.messages.terminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Attack;
import bgu.spl.mics.application.passiveObjects.Ewok;
import bgu.spl.mics.application.passiveObjects.Ewoks;

/**
 * LeiaMicroservices Initialized with Attack objects, and sends them as  {@link AttackEvent}.
 * This class may not hold references for objects which it is not responsible for:
 * {@link AttackEvent}.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class LeiaMicroservice extends MicroService {
	private Attack[] attacks;


    public LeiaMicroservice(Attack[] attacks) {
        super("Leia");
		this.attacks = attacks;
    }

//    public HashSet<Integer> create(Attack[] attack){
//        HashSet<Integer> hashSet = new HashSet();
//        for(int i=0;i<attacks.length;i=i+1){
//            List<Integer> list = attack[i].getSerials();
//            for(int serial : list){
//                hashSet.add(serial);
//            }
//        }
//        return hashSet;
//    }
//
//   public void addToEwoks(HashSet<Integer> hashSet){
//       Iterator<Integer> iterator = hashSet.iterator();
//       while(iterator.hasNext()){
//           Integer serialNumber = iterator.next();
//           Ewok ewok = new Ewok(serialNumber);
//           Ewoks.getInstance().addEwok(ewok);
//       }
//   }

    @Override
    protected void initialize() {
        try{
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.subscribeBroadcast(terminateBroadcast.class,(terminateBroadcast)->{
            this.terminate();
        });
    	for( int i = 0; i < attacks.length ; i = i + 1 ) {
    	    AttackEvent attackEvent = new AttackEvent(attacks[i]);
            Future<Boolean> future = this.sendEvent(attackEvent); // same because java pointer
            Ewoks.getInstance().addToEventFutureConcurrentHashMap(attackEvent,future);
            Ewoks.getInstance().addAttackEvent(attackEvent);
        }
    }

}
