package bgu.spl.mics.application.services;
import bgu.spl.mics.Future;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.Main;
import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.messages.BombDestroyerEvent;
import bgu.spl.mics.application.messages.DeactivationEvent;
import bgu.spl.mics.application.messages.terminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Diary;
import bgu.spl.mics.application.passiveObjects.Ewoks;

import java.util.Iterator;
import java.util.List;

/**
 * R2D2Microservices is in charge of the handling {@link DeactivationEvent}.
 * This class may not hold references for objects which it is not responsible for:
 * {@link DeactivationEvent}.
 *
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class R2D2Microservice extends MicroService {
    private long duration;

    public R2D2Microservice(long duration) {
        super("R2D2");
        this.duration = duration;
    }

    @Override
    protected void initialize() {
        List<AttackEvent> attackEventList = Ewoks.getInstance().getAttacklist();
        Iterator<AttackEvent> attacklist = attackEventList.iterator();
        while(attacklist.hasNext()){
            AttackEvent nextAttackEvent = attacklist.next();
            Ewoks.getInstance().getattackEventFutureConcurrentHashMap(nextAttackEvent).get();
        }
        this.subscribeEvent(DeactivationEvent.class,(deactivate)->{
            try {
                Thread.sleep(duration);
                this.complete(deactivate,true);
                Diary.getInstance().setR2D2Deactivate(System.currentTimeMillis());
                this.sendEvent(new BombDestroyerEvent());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        this.subscribeBroadcast(terminateBroadcast.class,(terminateBroadcast)->{
            this.terminate();
        });

    }
}
